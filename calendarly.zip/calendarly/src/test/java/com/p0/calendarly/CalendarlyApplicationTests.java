package com.p0.calendarly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalendarlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
