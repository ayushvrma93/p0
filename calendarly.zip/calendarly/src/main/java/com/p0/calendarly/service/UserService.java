package com.p0.calendarly.service;

import com.p0.calendarly.exceptions.CustomException;
import com.p0.calendarly.model.User;
import com.p0.calendarly.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User createUser(String email) throws CustomException {
        if (userRepository.findByEmail(email).isPresent()) {
            throw new CustomException("User already exists");
        }

        User user = new User();
        user.setEmail(email);
        return userRepository.save(user);
    }

    public User findById(Long id) throws CustomException {
        return userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));
    }

    public User findByEmail(String email) throws CustomException {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException("User not found"));
    }
}
